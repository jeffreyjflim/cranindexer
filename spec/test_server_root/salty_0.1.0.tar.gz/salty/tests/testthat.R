library(testthat)
library(salty)

test_check("salty")
