`aa0a1.a2` <-
function (typ,a,a0,a1)  switch (typ, b = aa0a1.a2.b(a,a0,a1),  l = aa0a1.a2.l(a,a0,a1),  v = aa0a1.a2.v(a,a0,a1),  h = aa0a1.a2.h(a,a0,a1)  )

