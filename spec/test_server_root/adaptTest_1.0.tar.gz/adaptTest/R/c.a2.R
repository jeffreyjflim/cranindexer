`c.a2` <-
function (typ,c)        switch (typ, b = c.a2.b(c),            l = c.a2.l(c),            v = c.a2.v(c),            h = c.a2.h(c)            )

