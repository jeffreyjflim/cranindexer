`aa0.a1a2` <-
function (typ,a,a0)     switch (typ, b = aa0.a1a2.b(a,a0),     l = aa0.a1a2.l(a,a0),     v = aa0.a1a2.v(a,a0),     h = aa0.a1a2.h(a,a0)     )

