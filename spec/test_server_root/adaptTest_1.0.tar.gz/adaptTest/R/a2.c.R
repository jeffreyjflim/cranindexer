`a2.c` <-
function (typ,a2)       switch (typ, b = a2.c.b(a2),           l = a2.c.l(a2),           v = a2.c.v(a2),           h = a2.c.h(a2)           )

