`distort.a2` <-
function (dis,f,a2) switch (dis, pl = distort.pl.a2(f,a2), vt = distort.vt.a2(f,a2))

