`p1p2.c.h` <-
function (p1,p2)    ifelse(!(le(0,p1) && le(p1,1) && le(0,p2) && le(p2,1)),              NA, p2)

