`c.a2.h` <-
function (c)        ifelse(!(le(0,c) && le(c,1)),                                        NA, c)

