`c.cef` <-
function (typ,c)        switch (typ, b = c.cef.b(c),           l = c.cef.l(c),           v = c.cef.v(c),           h = c.cef.h(c)           )

