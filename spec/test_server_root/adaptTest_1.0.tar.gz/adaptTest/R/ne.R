`ne` <-
function (x, y, tol=.Machine$double.eps^.5) !eq(x, y, tol)

