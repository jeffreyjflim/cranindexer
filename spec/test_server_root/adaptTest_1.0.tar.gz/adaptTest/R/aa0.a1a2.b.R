`aa0.a1a2.b` <-
function (a,a0, tol=.Machine$double.eps^.5)     ifelse(!(le(0,a) && le(a,a0) && le(a0,1)),                           NA, ifelse(eq(a,0)||eq(a,1)||eq(a,a0), a, uniroot(function(x) a0a1a2.a.b(a0,x,x) - a, lower=0, upper=a0, tol=tol)$root))

