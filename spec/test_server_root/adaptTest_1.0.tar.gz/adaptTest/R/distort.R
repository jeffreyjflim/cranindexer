`distort` <-
function (dis,f,p1,p2) switch (dis, pl = distort.pl(f,p1,p2), vt = distort.vt(f,p1,p2))

