`p1p2.cef.b` <-
function (p1,p2)    c.cef.b(p1p2.c.b(p1,p2))

