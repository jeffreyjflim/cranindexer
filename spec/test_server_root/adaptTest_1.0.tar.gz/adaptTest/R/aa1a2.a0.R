`aa1a2.a0` <-
function (typ,a,a1,a2)  switch (typ, b = aa1a2.a0.b(a,a1,a2),  l = aa1a2.a0.l(a,a1,a2),  v = aa1a2.a0.v(a,a1,a2),  h = aa1a2.a0.h(a,a1,a2)  )

