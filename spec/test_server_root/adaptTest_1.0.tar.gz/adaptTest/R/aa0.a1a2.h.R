`aa0.a1a2.h` <-
function (a,a0)     ifelse(!(le(0,a) && le(a,a0) && le(a0,1)),                           NA, (1+a0)/2 - sqrt(((1+a0)/2)^2-a))

