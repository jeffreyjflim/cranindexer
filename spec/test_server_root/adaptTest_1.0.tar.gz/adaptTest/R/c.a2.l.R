`c.a2.l` <-
function (c)                                                                                 1-pnorm(c)

